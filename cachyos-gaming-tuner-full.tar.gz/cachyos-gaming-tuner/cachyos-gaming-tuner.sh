#!/bin/bash

# === CACHYOS GAMING TUNER v2 (ZENITY GUI ENABLED) ===
# By Alb Kestrel

# Root check
if [[ $EUID -ne 0 ]]; then
  echo "🚫 Please run as root"
  exit 1
fi

# Ensure zenity
if ! command -v zenity &> /dev/null; then
    pacman -S --noconfirm zenity
fi

# Zenity menu
choices=$(zenity --list --checklist \
  --title="CachyOS Gaming Setup" \
  --width=500 --height=600 \
  --text="Select the features you want to enable:" \
  --column="Enable" --column="Feature" \
  TRUE "Install Steam, Wine, ProtonUp-Qt" \
  TRUE "Install OBS Studio + 720p Profile" \
  TRUE "Enable MangoHud + GameMode" \
  TRUE "Apply RX 6800 Fan Curve on Login" \
  FALSE "Install VKBasalt with CAS Shader" \
  FALSE "Install Lutris & Heroic Games Launcher" \
  FALSE "Enable KDE Gaming Layout (Latte Dock)" \
  FALSE "Add Backup Reminder Popup" \
  FALSE "Disable KDE File Indexer (Baloo)" \
  FALSE "Configure HugePages for Game Load Boost" \
  FALSE "Install CoreCtrl GPU OC Manager" \
  --separator="|")

IFS="|" read -r -a features <<< "$choices"

# Feature functions
source /opt/cachyos-gaming/modules/install_steam.sh
source /opt/cachyos-gaming/modules/install_obs.sh
source /opt/cachyos-gaming/modules/setup_mangohud.sh
source /opt/cachyos-gaming/modules/fan_curve_rx6800.sh
source /opt/cachyos-gaming/modules/install_vkbasalt.sh
source /opt/cachyos-gaming/modules/install_lutris_heroic.sh
source /opt/cachyos-gaming/modules/enable_kde_layout.sh
source /opt/cachyos-gaming/modules/backup_reminder.sh
source /opt/cachyos-gaming/modules/disable_baloo.sh
source /opt/cachyos-gaming/modules/enable_hugepages.sh
source /opt/cachyos-gaming/modules/install_corectrl.sh

zenity --info --title="CachyOS Gaming Tuner" --text="✅ All selected features installed. Reboot to finalize setup."
