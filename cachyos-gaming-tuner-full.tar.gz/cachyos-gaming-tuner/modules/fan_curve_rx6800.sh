#!/bin/bash
[[ " ${features[@]} " =~ "Apply RX 6800 Fan Curve on Login" ]] && echo "RX 6800 fan curve would be applied here"