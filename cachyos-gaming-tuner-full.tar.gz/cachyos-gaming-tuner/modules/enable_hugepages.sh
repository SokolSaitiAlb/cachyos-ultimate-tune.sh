#!/bin/bash
[[ " ${features[@]} " =~ "Configure HugePages for Game Load Boost" ]] && echo 'vm.nr_hugepages=128' >> /etc/sysctl.d/10-hugepages.conf