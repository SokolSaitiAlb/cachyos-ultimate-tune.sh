#!/bin/bash
[[ " ${features[@]} " =~ "Install Lutris & Heroic Games Launcher" ]] && pacman -S --noconfirm lutris heroic-games-launcher