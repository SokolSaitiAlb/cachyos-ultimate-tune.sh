zenity --info --title="Rregulluesi i Lojërave për CachyOS" \
--text="✅ Veçoritë e përzgjedhura u instaluan me sukses. \
Rinisni sistemin për të përfunduar konfigurimin."
