#!/bin/bash
[[ " ${features[@]} " =~ "Install Steam, Wine, ProtonUp-Qt" ]] && pacman -S --noconfirm steam wine protonup-qt