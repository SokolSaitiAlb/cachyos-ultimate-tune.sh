#!/bin/bash
[[ " ${features[@]} " =~ "Install OBS Studio + 720p Profile" ]] && pacman -S --noconfirm obs-studio