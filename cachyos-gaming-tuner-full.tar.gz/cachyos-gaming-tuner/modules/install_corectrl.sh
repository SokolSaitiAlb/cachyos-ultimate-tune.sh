#!/bin/bash
[[ " ${features[@]} " =~ "Install CoreCtrl GPU OC Manager" ]] && pacman -S --noconfirm corectrl