#!/bin/bash
[[ " ${features[@]} " =~ "Install VKBasalt with CAS Shader" ]] && pacman -S --noconfirm vkbasalt