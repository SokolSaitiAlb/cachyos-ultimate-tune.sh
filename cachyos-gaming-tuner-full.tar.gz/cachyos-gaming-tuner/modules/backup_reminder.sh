#!/bin/bash
[[ " ${features[@]} " =~ "Add Backup Reminder Popup" ]] && echo 'notify-send "Backup Reminder" "Backup your game saves!"' > ~/.local/bin/backup-reminder.sh