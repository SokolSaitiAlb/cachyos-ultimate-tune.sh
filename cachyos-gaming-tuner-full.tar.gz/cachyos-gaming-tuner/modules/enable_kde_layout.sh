#!/bin/bash
[[ " ${features[@]} " =~ "Enable KDE Gaming Layout (Latte Dock)" ]] && echo "KDE gaming layout activated"