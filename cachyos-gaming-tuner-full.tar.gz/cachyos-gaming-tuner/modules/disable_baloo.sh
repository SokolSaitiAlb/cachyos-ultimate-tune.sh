#!/bin/bash
[[ " ${features[@]} " =~ "Disable KDE File Indexer (Baloo)" ]] && balooctl disable