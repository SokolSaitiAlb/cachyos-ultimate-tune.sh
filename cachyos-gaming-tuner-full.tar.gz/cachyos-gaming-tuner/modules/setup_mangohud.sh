#!/bin/bash
[[ " ${features[@]} " =~ "Enable MangoHud + GameMode" ]] && pacman -S --noconfirm mangohud gamemode