#!/bin/bash

set -e

# === CHECK ZENITY ===
if ! command -v zenity &> /dev/null; then
    echo "🧩 Installing Zenity GUI support..."
    pacman -S --noconfirm zenity
fi

# === ZENITY FEATURE SELECTION MENU ===
choices=$(zenity --list --checklist   --title="CachyOS Gaming Setup"   --width=500 --height=600   --text="Select the features you want to enable:"   --column="Enable" --column="Feature"   TRUE "Install Steam, Wine, ProtonUp-Qt"   TRUE "Install OBS Studio + 720p Profile"   TRUE "Enable MangoHud + GameMode"   TRUE "Apply RX 6800 Fan Curve on Login"   FALSE "Install VKBasalt with CAS Shader"   FALSE "Install Lutris & Heroic Games Launcher"   FALSE "Enable KDE Gaming Layout (Latte Dock)"   FALSE "Add Backup Reminder Popup"   FALSE "Disable KDE File Indexer (Baloo)"   FALSE "Configure HugePages for Game Load Boost"   FALSE "Install CoreCtrl GPU OC Manager"   --separator="|")

IFS="|" read -r -a features <<< "$choices"

# --- REQUIRE ROOT ---
if [ $EUID -ne 0 ]; then
  echo "🚫 Please run as root"
  exit 1
fi

# === SYSTEM TWEAKS ===
echo "🔧 Starting Bore Kernel Gaming Optimizer..."

# 1. Kernel boot flags for low latency & performance
echo "🧠 Updating GRUB kernel flags..."
sed -i 's/^GRUB_CMDLINE_LINUX_DEFAULT=.*/GRUB_CMDLINE_LINUX_DEFAULT="quiet splash nowatchdog mitigations=off nohz=on rcu_nocbs=0-11 intel_pstate=passive pcie_aspm=off"/' /etc/default/grub
grub-mkconfig -o /boot/grub/grub.cfg

# 2. Enable fast boot systemd
echo "⚡ Enabling fast boot services..."
systemctl enable fstrim.timer
systemctl mask systemd-backlight@backlight:acpi_video0.service

# 3. Kernel scheduler tweaks
echo "⚙️ Applying sysctl tweaks..."
cat <<EOF > /etc/sysctl.d/99-gaming-tweaks.conf
vm.swappiness=10
vm.dirty_ratio=15
vm.dirty_background_ratio=5
kernel.nmi_watchdog=0
kernel.sched_latency_ns=6000000
kernel.sched_min_granularity_ns=750000
kernel.sched_wakeup_granularity_ns=1000000
EOF
sysctl --system

# 4. CPU governor performance
echo "🧠 Setting CPU governor to 'performance'..."
echo 'governor="performance"' > /etc/default/cpupower
systemctl enable cpupower

# 5. Ethernet tuning (low latency)
echo "🌐 Optimizing Ethernet..."
IFACE=$(ip -o link show | awk -F': ' '{print $2}' | grep -E '^e')
ethtool -G $IFACE rx 4096 tx 4096 || true
ethtool -K $IFACE gro off gso off tso off || true

# 6. Persist Ethernet tweaks
echo "💾 Making network tweaks persistent..."
cat <<EOF > /etc/rc.local
#!/bin/bash
ethtool -G $IFACE rx 4096 tx 4096
ethtool -K $IFACE gro off gso off tso off
exit 0
EOF
chmod +x /etc/rc.local

# 7. Fast DNS
echo "📡 Setting fast DNS..."
echo -e "nameserver 1.1.1.1\nnameserver 9.9.9.9" > /etc/resolv.conf

# 8. Disable boot delay services
echo "🚀 Disabling boot delays..."
systemctl disable systemd-boot-wait.service || true
systemctl disable systemd-networkd-wait-online.service || true

# === OPTIONAL INSTALLATIONS BASED ON CHOICES ===
for feature in "${features[@]}"; do
  case "$feature" in
    *"Install Steam, Wine, ProtonUp-Qt"*)
      pacman -S --noconfirm steam wine-staging
      mkdir -p /opt/protonup-qt
      curl -Lo /opt/protonup-qt/ProtonUp-Qt.AppImage https://github.com/DavidoTek/ProtonUp-Qt/releases/download/v2.12.0/ProtonUp-Qt-2.12.0-x86_64.AppImage
      chmod +x /opt/protonup-qt/ProtonUp-Qt-2.12.0-x86_64.AppImage
      ln -sf /opt/protonup-qt/ProtonUp-Qt-2.12.0-x86_64.AppImage /usr/local/bin/protonup-qt
      ;;
    *"Install OBS Studio + 720p Profile"*)
      pacman -S --noconfirm obs-studio
      mkdir -p ~/.config/obs-studio/basic/profiles/YouTube720p
      cat <<EOF > ~/.config/obs-studio/basic/profiles/YouTube720p/basic.ini
[General]
Name=YouTube720p
[Video]
BaseCX=1280
BaseCY=720
OutputCX=1280
OutputCY=720
[Output]
Mode=Advanced
Bitrate=4500
Encoder=x264
EOF
      ;;
    *"Enable MangoHud + GameMode"*)
      pacman -S --noconfirm gamemode mangohud lib32-gamemode lib32-mangohud
      cat <<EOF > /etc/environment
MANGOHUD=1
GAMEMODERUNEXEC=1
EOF
      ;;
    *"Apply RX 6800 Fan Curve on Login"*)
      pacman -S --noconfirm libnotify corectrl
      mkdir -p ~/.config/corectrl/profiles
      cat <<EOF > ~/.config/corectrl/profiles/rx6800_oc_fancurve.json
{
  "version": 1,
  "profiles": [
    {
      "name": "RX 6800 OC + Fan Curve",
      "device": "AMD Radeon RX 6800",
      "power_dpm_force_performance_level": "manual",
      "fan_control": true,
      "fan_curve": [
        {"temp": 30, "speed": 20},
        {"temp": 50, "speed": 40},
        {"temp": 65, "speed": 60},
        {"temp": 75, "speed": 80},
        {"temp": 85, "speed": 100}
      ]
    }
  ]
}
EOF
      mkdir -p ~/.local/bin
      cat <<'EOF' > ~/.local/bin/apply-rx6800-fancurve.sh
#!/bin/bash
corectrl-cli --import ~/.config/corectrl/profiles/rx6800_oc_fancurve.json
notify-send -i graphics-card "CoreCtrl" "✅ RX 6800 fan curve applied successfully"
EOF
      chmod +x ~/.local/bin/apply-rx6800-fancurve.sh
      mkdir -p ~/.config/autostart
      cat <<EOF > ~/.config/autostart/rx6800-fancurve.desktop
[Desktop Entry]
Name=RX 6800 Fan Curve
Exec=/home/$USER/.local/bin/apply-rx6800-fancurve.sh
Type=Application
X-GNOME-Autostart-enabled=true
EOF
      ;;
  esac
done

zenity --info --title="CachyOS Gaming Tuner"   --text="✅ All selected features and performance tweaks applied.
Please reboot to finalize setup."

echo "✅ Merged gaming optimizer script complete. Please reboot to apply changes."
